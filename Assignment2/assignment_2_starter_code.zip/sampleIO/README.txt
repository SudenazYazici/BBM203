				
				██████╗ ██╗      ██████╗  ██████╗██╗  ██╗███████╗ █████╗ ██╗     ██╗     
				██╔══██╗██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗██║     ██║     
				██████╔╝██║     ██║   ██║██║     █████╔╝ █████╗  ███████║██║     ██║     
				██╔══██╗██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██╔══██║██║     ██║     
				██████╔╝███████╗╚██████╔╝╚██████╗██║  ██╗██║     ██║  ██║███████╗███████╗
				╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝
																									
███████████████████████████████████████████████████████████████████████████████████████████████████████

"leaderboard.txt" is the starting leaderboard before any plays. 

In the "run_commands.txt", you are given the run commands for each play in order. 

Each play should be run with its corresponding input files; e.g.,
Play 1 should be run with the following command:

blockfall samples/1_big_grid_gravity_switch/grid.dat samples/1_big_grid_gravity_switch/blocks.dat samples/1_big_grid_gravity_switch/commands.dat GRAVITY_OFF samples/leaderboard.txt InfiniteLooper

while using the input files from the "1_big_grid_gravity_switch" folder.

The folder "outputs" contains expected STDOUT for each given play. 
The "final_leaderboard_after_all_plays.txt" file is the final expected leaderboard state after all 
given plays. 

███████████████████████████████████████████████████████████████████████████████████████████████████████
					
					██╗  ██╗ █████╗ ██╗   ██╗███████╗    ███████╗██╗   ██╗███╗   ██╗██╗
					██║  ██║██╔══██╗██║   ██║██╔════╝    ██╔════╝██║   ██║████╗  ██║██║
					███████║███████║██║   ██║█████╗      █████╗  ██║   ██║██╔██╗ ██║██║
					██╔══██║██╔══██║╚██╗ ██╔╝██╔══╝      ██╔══╝  ██║   ██║██║╚██╗██║╚═╝
					██║  ██║██║  ██║ ╚████╔╝ ███████╗    ██║     ╚██████╔╝██║ ╚████║██╗
					╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝    ╚═╝      ╚═════╝ ╚═╝  ╚═══╝╚═╝
																					